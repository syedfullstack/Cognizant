package com.cognizant;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class AgeService {

	public String calculateAge(String date) {
	   // System.out.println("date-------------> "+date);
	   Period period=null;
		try {
			Date d= new SimpleDateFormat("dd-MM-yyyy").parse(date);
			Instant instant = d.toInstant();
            ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
            LocalDate givenDate = zone.toLocalDate();
            
            period = Period.between(givenDate, LocalDate.now());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "you are "+period.getYears()+" years, "+period.getMonths()+" months, "+period.getDays()+" days old.";
	}
}
