
import java.lang.*;

public class CharacterSubsetDemo extends Character.Subset {
  
   // constructor of super class
   CharacterSubsetDemo(String s) {
      super(s); 
   }

   public static void main(String[] args) {

      CharacterSubsetDemo obj1 = new CharacterSubsetDemo("admin");
      CharacterSubsetDemo obj2 = new CharacterSubsetDemo("admin");
      CharacterSubsetDemo obj3 = new CharacterSubsetDemo("administrator");

      // returns a hash code value
      int retval = obj1.hashCode();
      System.out.println("Hash code of Object " + obj1 + " = " + retval);
      retval = obj2.hashCode();
      System.out.println("Hash code of Object " + obj2 + " = " + retval);
      retval = obj3.hashCode();
      System.out.println("Hash code of Object " + obj3 + " = " + retval);
   }
} 