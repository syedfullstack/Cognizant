
public class IBMDB2DB implements MyInter {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("-Connecting IBMDB2 Database ");

	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("==================================");
		System.out.println("----DisConnecting IBMDB2 Database ");

	}

}