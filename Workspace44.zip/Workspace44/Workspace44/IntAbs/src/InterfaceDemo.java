
public class InterfaceDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Class c= Class.forName(args[0]);
		
		MyInter mi=(MyInter)c.newInstance();
		
		mi.connect();
		mi.disconnect();
		
		
		
		
		

	}

}



/*
Class cls = Class.forName("ClassName");


ClassName objectName = (ClassName) cls.newInstance();


*/