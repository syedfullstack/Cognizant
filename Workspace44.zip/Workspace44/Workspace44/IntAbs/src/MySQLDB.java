

public class MySQLDB implements MyInter {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("-Connecting MySQL Database ");

	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("==================================");
		System.out.println("----DisConnecting MySQL Database ");

	}

}
