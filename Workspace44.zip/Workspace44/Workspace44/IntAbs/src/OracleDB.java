
public class OracleDB implements MyInter {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("-Connecting Oracle Database ");

	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("==================================");
		System.out.println("----DisConnecting Oracle Database ");

	}

}
