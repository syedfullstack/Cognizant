
public interface MyInter {
	
	 void connect();
	 void disconnect();

}
