
abstract class Plan
{
	
	public double rate;
	
	
	public abstract void getRate();
	
	public void calculateBill(int units)
	{
		System.out.println("===============================");
		System.out.println("Bill amount for "+units+" units:");
		System.out.println(rate*units);
	}
	
	
	
}

class CommercialPlan extends Plan
{

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		
		rate=9.00;
		
	}
	
	
}


class DomesticlPlan extends Plan
{

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		
		rate=5.00;
		
	}
	
	
}










public class Calculate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Plan p;
		
		
		System.out.println("Commercial Connection");
		
		p=new CommercialPlan();
		
		p.getRate();
		
		p.calculateBill(250);
		
		
		
		System.out.println("Domestic Connection");
		p=new DomesticlPlan();
		
		p.getRate();
		p.calculateBill(250);
		
		
	}

}
