package com.abstraction;

 abstract class Plan {
	
	// take rate as protected to access it in Sub Classes
	
	protected double rate;
	
	//accept rate into rate variable.Since rate will Change
	
	public abstract void getRate();
	
	//Calculate the electricity bill by taking units.
	
	public void calculateBill(int units)
	{
		
		System.out.println("Bill amount for"+units+"Units");
		System.out.println(rate*units);
		System.out.println("====================");
	}
	
	
	

}
