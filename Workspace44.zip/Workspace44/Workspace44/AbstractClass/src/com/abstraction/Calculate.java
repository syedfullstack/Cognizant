package com.abstraction;

public class Calculate {

	public static void main(String[] args) {
		
		//Create reference p to abstract class
		
		Plan p;
		
		//Calculate commercial bill for 250 Units
		
		System.out.println("Commercial Connection");
		
		p=new CommercialPlan();
		p.getRate();
		p.calculateBill(250);
		
		
		//Calculate Domestic bill for 250 Units
		
				System.out.println("Domestic Connection");
				
				p=new DomesticPlan();
				p.getRate();
				p.calculateBill(150);
				
		
		

	}

}
