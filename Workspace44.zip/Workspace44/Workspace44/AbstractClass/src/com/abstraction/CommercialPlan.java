package com.abstraction;

class CommercialPlan extends Plan {
	
	//Store Commercial rate as 5.00 per Unit

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		
		rate=5.00;

	}

}
