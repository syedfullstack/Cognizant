package com.abstraction;

public class StringExample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String str1="Hello";
		
		String str2="Hello";
		
		StringBuilder str3=new StringBuilder("Hello");
		
		StringBuilder str4=new StringBuilder("Hello");
		
		String str5=new String("Hello1");
		
		String str6=new String("Hello1");
		
		
		
        StringBuffer str7=new StringBuffer("Hello");
		
		StringBuffer str8=new StringBuffer("Hello");
		
		
		//String Immutable
		
		System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str3.hashCode());
		System.out.println(str4.hashCode());
		System.out.println(str5.hashCode());
		System.out.println(str6.hashCode());
		System.out.println(str7.hashCode());
		System.out.println(str8.hashCode());
		
				
		

	}

}
