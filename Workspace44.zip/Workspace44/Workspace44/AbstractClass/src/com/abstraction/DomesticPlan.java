package com.abstraction;

class DomesticPlan extends Plan {

	@Override
	public void getRate() {
		// TODO Auto-generated method stub
		
		rate=2.00;

	}

}
