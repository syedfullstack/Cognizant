package constructor;

public class Exemple2 {
	int i ;
	
	public Exemple2(int i) {
		this.i = i;
	}
	
	public static void main(String[] args) {
		//Exemple2 obj = new Exemple2();
		
		Exemple2 obj1 = new Exemple2(7);
	}
}
