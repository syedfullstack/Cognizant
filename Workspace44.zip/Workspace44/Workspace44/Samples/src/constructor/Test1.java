package constructor;

public class Test1 {
	int a;
    int b;
    
	Test1(int a, int b) {
		this.a = a;
		this.b = b;
	}
	
	
}
