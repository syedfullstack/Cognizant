package exception;

public class Example4 {

	public static void main(String[] args) {
		String s1 = null;
		System.out.println(s1.toString());
	}
}
