package testInheritance;

public class A {
	
	public void test1(){
		System.out.println("A test1");
	}

}
