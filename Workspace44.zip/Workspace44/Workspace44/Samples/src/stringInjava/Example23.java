package stringInjava;

public class Example23 {

	public static void main(String args[]) {
		String s1 = "bhanujava";
		String s2 = "test";
		System.out.println("string length is: " + s1.length());
		System.out.println("string length is: " + s2.length());
	}

}
