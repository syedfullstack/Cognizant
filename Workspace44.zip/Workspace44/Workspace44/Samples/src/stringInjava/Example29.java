package stringInjava;

public class Example29 {

	public static void main(String[] args) {
		String s = "hello java";

		System.out.println(s.toUpperCase());

		String s1 = "HELLO";

		System.out.println(s1.toLowerCase());
	}
}
