package stringInjava;

public class Example5 {

	public static void main(String[] args) {
		String name = "bhanupratap";
		char ch = name.charAt(4);
		System.out.println(ch);
		
		name.charAt(20);
	}
}
