package stringInjava;

public class Example7 {

	public static void main(String[] args) {
		String name = "Hello java program";
		System.out.println(name.contains("java program"));
		System.out.println(name.contains("am"));
		System.out.println(name.contains("hello"));
	}
}
