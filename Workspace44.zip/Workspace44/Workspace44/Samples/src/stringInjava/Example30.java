package stringInjava;

public class Example30 {
	
	public static void main(String[] args) {
		String s1 = " Hello Java ";
		
		System.out.println("123"+s1.trim()+"12");
		
		
		System.out.println("123"+s1+"12");
	}
}
