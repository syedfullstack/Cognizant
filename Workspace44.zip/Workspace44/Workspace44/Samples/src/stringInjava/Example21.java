package stringInjava;

public class Example21 {

	public static void main(String[] args) {
		String d = String.join("/", "20", "04", "2016");
		System.out.print(d);
		String t = String.join(":", "11", "13", "10");
		System.out.println(t);
	}

}
