package stringInjava;

public class Example6 {

	public static void main(String[] args) {

	}

}
