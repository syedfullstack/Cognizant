package stringInjava;

public class Example24 {

	public static void main(String args[]) {
		String s1 = "hello java test";
		String replaceString = s1.replace('a', 'e');
		System.out.println(replaceString);
	}
}
