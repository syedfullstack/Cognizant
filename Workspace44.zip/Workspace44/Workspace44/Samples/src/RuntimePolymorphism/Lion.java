package RuntimePolymorphism;

public class Lion extends Animal{

	void eat() {
		System.out.println("eats meat...");
	}
}
