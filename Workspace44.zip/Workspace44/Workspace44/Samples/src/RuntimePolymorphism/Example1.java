package RuntimePolymorphism;

public class Example1 {

	void run() {
		System.out.println("running");
	}
}
