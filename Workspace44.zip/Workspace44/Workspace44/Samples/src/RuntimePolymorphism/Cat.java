package RuntimePolymorphism;

public class Cat extends Animal{

	void eat() {
		System.out.println("eats rat...");
	}
}
