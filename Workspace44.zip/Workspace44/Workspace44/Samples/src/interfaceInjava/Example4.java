package interfaceInjava;

public interface Example4 {

	//Example4 example4;

	int i = 90;

}
