package interfaceInjava;

public interface Example5 {

	void method5();
}
