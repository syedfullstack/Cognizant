package interfaceInjava;

public interface Example2 {

	int i = 90;

	void test1();
	
	void test2();
}
