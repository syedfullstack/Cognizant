package interfaceInjava;

public interface Example3 {

	
//	Example3(){
//		
//	}
}
