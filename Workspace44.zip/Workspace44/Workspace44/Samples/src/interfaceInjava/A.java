package interfaceInjava;

public interface A {

}

class B implements A {

}
