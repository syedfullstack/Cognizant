package staticBlock;

public class Example8 {
	
	static void test1(){
		System.out.println("test1()");
	}
	
	public static void main(String[] args) {
		test1();
	}
}
