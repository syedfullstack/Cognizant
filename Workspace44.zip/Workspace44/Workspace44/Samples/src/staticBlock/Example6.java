package staticBlock;

public class Example6 {
	
	int i = 90;
	static int k = 80;
	static{
		k = 100;
		//i = 60;
	}

}
