package staticBlock;

public class Example10 {
	
	public static void main(String[] args) {
		Example9.test1();
		
		//Example9.test2();
	}
}
