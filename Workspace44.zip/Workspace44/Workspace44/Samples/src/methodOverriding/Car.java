package methodOverriding;

public class Car extends Vehicle{

	public void run(){
		System.out.println("runs at 180KM/H");
	}
}
