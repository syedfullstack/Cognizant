package inheritanceInJava;

public class ParentClass {

	public void test1() {
     System.out.println("ParentClass test1()");
	}

	public void test2() {
		System.out.println("ParentClass test2()");
	}

	public void test3() {
		System.out.println("ParentClass test3()");
	}

}
