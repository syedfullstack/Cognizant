package methodOverloading;

public class Overloading10 {

	Overloading10(int i) {

	}

	Overloading10() {

	}
}
