package BasicOfJava;

public class Employee {
	
	int i;
	int j;
	Person person;

}
