package methodOverridingInJava;

public class Example1 {
	
	public void test1(){
		System.out.println("Example1 test1()");
	}
	
	public void test2(){
		System.out.println("Example1 test2()");
	}

}
