package encapsulationInJava;

public class TestExample4 {
	
	public static void main(String[] args) {
		
		Example4 obj = new Example4();
		obj.setStudentName("Ram");
		
		System.out.println(obj);
	}
}
