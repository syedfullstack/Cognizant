package accessmodifier;

public class Example2 {

	public static void main(String[] args) {

		Example1 example1 = new Example1();

		example1.name1();
		example1.name2();
		example1.name4();

		System.out.println(example1.s1);
		System.out.println(example1.s3);
		System.out.println(example1.s4);
	}

}
