package inheritance;

public class Conts2 extends Conts1{
	
	public static void main(String[] args) {
		Conts2 conts2 = new Conts2(4);
		
		Conts2 conts3 = new Conts2();
	}
}
