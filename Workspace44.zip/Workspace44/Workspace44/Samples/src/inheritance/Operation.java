package inheritance;

public class Operation {

	int square(int n) {
		return n * n;
	}

	int circle(int radious) {
		return (22 / 7) * radious;
	}
	
	int rectangle(int length,int width) {
		return width*length;
	}

}
