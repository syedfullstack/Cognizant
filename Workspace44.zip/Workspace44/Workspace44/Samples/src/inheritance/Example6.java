//package inheritance;
//
//public class Example6 extends Example3,Example4{
//
//}
