package inheritance;

public class Example3 {
	
	void msg(){
		
	}
}
