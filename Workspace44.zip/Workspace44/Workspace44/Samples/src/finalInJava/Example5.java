package finalInJava;

public class Example5 extends Example4{

}
