package finalInJava;

public class Example10 {
	
	
	//final Example10(){
		
	//}

}
