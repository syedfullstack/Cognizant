package anonymousInnerClass;

public interface State {

	void population();

	void numberOfDistrict();

}
