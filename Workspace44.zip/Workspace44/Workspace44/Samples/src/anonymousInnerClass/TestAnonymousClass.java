package anonymousInnerClass;

public class TestAnonymousClass {

	public static void main(String[] args) {
		
		TestState testState = new TestState();
		testState.biharState.population();
		testState.upState.population();
		
		testState.upState.numberOfDistrict();
		
		testState.biharState.numberOfDistrict();
		
	}

}
