package ReturnTypeInJava;

public class Notes {

	/**
	The data type of the return value must match the method's declared return type We can't return an integer 
	value from a method whose declaration type is void.
	 */
}
