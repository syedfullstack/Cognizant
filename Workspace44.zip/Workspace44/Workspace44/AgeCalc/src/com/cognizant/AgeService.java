package com.cognizant;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;
import java.util.Date;
import java.time.Instant;
import java.time.ZoneId;
import java.time.ZonedDateTime;

public class AgeService {

	public String calculateAge(String date) {
	   // System.out.println("date-------------> "+date);
	   Period period=null;
		try {
			Date d= new SimpleDateFormat("dd-MM-yyyy").parse(date);
			Instant instant = d.toInstant();
            ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
            LocalDate givenDate = zone.toLocalDate();
            
            period = Period.between(givenDate, LocalDate.now());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		return "you are "+period.getYears()+" years, "+period.getMonths()+" months, "+period.getDays()+" days old.";
	}
}

/*
  yyyy-MM-dd 

  LocalDate pdate = LocalDate.parse(date);
   14         LocalDate now = LocalDate.now();
   15         
   16         Period diff = Period.between(pdate, now);
   17    
   18        String ans="you are "+diff.getYears()+" years, "+diff.getMonths()+" months, "+diff.getDays()+" days old.";
   19 		return ans;


*/