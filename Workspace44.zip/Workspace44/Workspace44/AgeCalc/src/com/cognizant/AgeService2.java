package com.cognizant;

import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeFormatter;

public class AgeService2 {
    public String calculateAge(String date) {
        //LocalDate localDate = LocalDate.parse(date, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
      //  Period period = Period.between(localDate, LocalDate.now());
    	LocalDate pdate = LocalDate.parse(date);
    	//LocalDate pdate = LocalDate.parse("2019-03-29");
        LocalDate now = LocalDate.now();
        Period diff = Period.between(pdate, now);
        //int years = period.getYears();
        //int months = period.getMonths();
        //int days = period.getDays();
        //2019-03-29
        //return "you are " + years + " years, " + months + " months, " + days + " days old.";
        String ans="you are "+diff.getYears()+" years, "+diff.getMonths()+" months, "+diff.getDays()+" days old.";
		return ans;
    }
}


/*
  yyyy-MM-dd 

  LocalDate pdate = LocalDate.parse(date);
   14         LocalDate now = LocalDate.now();
   15         
   16         Period diff = Period.between(pdate, now);
   17    
   18        String ans="you are "+diff.getYears()+" years, "+diff.getMonths()+" months, "+diff.getDays()+" days old.";
   19 		return ans;


*/