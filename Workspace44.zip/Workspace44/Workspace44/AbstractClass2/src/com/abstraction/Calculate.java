package com.abstraction;

import java.util.*;  

public class Calculate {

	public static void main(String[] args) {
		
		//Create reference p to abstract class
		
		Plan p;
		
		//Calculate commercial bill for 250 Units
		
		System.out.println("1.Commercial Connection");
		System.out.println("2.Domestic Plan Connection");
		System.out.println("3.Exit");
						
		Scanner sc= new Scanner(System.in); 
		
		System.out.print("Please Enter the Plan :");
		//System.out.print("======================");
		int a= sc.nextInt();
		
		
		if (a==1) {
			  System.out.println("Commercial Plan");
			} else if (a==2) {
			  System.out.println("Domestic Plan");
			}else if(a==3) {
			  System.out.println("System Exit");
			  System.exit(0);
			} else {
			  System.out.println("Invalid no");
			}
		
		
		
		
	/*	//System.in is a standard input stream  
		System.out.print("Enter first number- ");  
		int a= sc.nextInt();  
		System.out.print("Enter second number- ");  
		int b= sc.nextInt();  
		
		p=new CommercialPlan();
		p.getRate();
		p.calculateBill(250);
		
		
		//Calculate Domestic bill for 250 Units
		
				System.out.println("Domestic Connection");
				
				p=new DomesticPlan();
				p.getRate();
				p.calculateBill(150);
				
				
				/*if (time < 10) {
					  System.out.println("Good morning.");
					} else if (time < 20) {
					  System.out.println("Good day.");
					} else {
					  System.out.println("Good evening.");
					}
					
					*/
				
		
		

	}

}
