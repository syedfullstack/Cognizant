package com.infexample;

public class OracleBD implements MyInter {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("Connecting Oracle Databse");

	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("DisConnecting Oracle Databse");

	}

}
