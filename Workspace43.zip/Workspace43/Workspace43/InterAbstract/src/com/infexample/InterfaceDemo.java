package com.infexample;





class MySQLDB implements MyInter {

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		
		System.out.println("Connecting MySQL Databse");

	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		
		System.out.println("DisConnecting MySQL Databse");

	}

}



public class InterfaceDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		
		Class C=Class.forName(args[0]);
		MyInter mi=(MyInter)C.newInstance();
		
		mi.connect();
		mi.disconnect();
		
		
		
		

	}

}
