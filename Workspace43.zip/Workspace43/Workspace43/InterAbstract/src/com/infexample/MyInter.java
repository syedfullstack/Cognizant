package com.infexample;

public interface MyInter {
	
	
	void connect();
	void disconnect();

}