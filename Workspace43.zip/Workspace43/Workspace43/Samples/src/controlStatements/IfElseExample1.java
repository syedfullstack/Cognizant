package controlStatements;

public class IfElseExample1 {

	public void testAge(int age) {
		if (age > 18) {
			System.out.println("Person is Major");
		} else {
			System.out.println("Person is Minor");
		}
	}
}
