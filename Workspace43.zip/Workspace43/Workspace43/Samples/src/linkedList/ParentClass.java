package linkedList;

public interface ParentClass {
	
	void add();
	
	void test();

}
