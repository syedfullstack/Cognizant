package instanceOfInJava;

public class Animal {

}
