package exception;

public class Example3 {

	public static void main(String[] args) {
		int a[] = { 10, 20, 30 };
		System.out.println(a[8]);
	}
}
