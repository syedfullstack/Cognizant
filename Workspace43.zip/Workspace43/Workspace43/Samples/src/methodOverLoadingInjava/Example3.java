package methodOverLoadingInjava;

public class Example3 {
/*
	public void test1() {
		System.out.println("test1()");
	}

	public int test1() {
		System.out.println("test1()");
		return 2;
	}
*/
	public final void test2() {

	}

	public final void test2(int i) {

	}
	
	public static void test3() {
		System.out.println("test1()");
	}
	
	public static void test3(int p) {
		System.out.println("test1()");
	}

}
