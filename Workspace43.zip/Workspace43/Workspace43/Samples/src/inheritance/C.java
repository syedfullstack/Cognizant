package inheritance;

public class C {
	
	private int a;
	
	public int b;

}
