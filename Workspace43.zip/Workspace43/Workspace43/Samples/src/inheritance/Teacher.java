package inheritance;

public class Teacher {
	
	String designation = "Teacher";
	String collegeName = "L.S College Muzaffarpur";

	void does() {
		System.out.println("Teaching");
	}
}
