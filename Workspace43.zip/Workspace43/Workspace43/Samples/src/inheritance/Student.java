package inheritance;

public class Student {
	
	public String Schooladdress;

	private String SchoolName;
	
	
	public String getSchooladdress() {
		return "Muzaffarpur Bihar 560100";
	}

	public String getSchoolName() {
		return "DAV";
	}
}
