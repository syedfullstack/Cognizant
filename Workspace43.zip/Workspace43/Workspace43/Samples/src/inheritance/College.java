package inheritance;

public class College {

	public String collegeName = "LS COLLEGE";

}
