package inheritance;

public class Exaple1 {

}
