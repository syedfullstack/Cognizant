package methodOverriding;

public class Bank {
	
	public int rateOfInterest(){
		System.out.println("rateOfInterest= 0%");
		return 0;
	}
}
