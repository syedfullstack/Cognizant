package methodOverriding;

public class Jeep  extends Vehicle{

}
