package methodOverriding;

public class Bike  extends Vehicle{

}
