package methodOverriding;

public class ICICI extends Bank{

}
