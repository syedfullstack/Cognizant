package methodOverriding;

public class Example1 {

	 static void test1() {
		System.out.println("Example1");
	}

	 static void test2() {
		System.out.println("Example1 test2");
	}
}
