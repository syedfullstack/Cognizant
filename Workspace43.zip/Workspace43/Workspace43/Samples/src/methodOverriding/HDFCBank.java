package methodOverriding;

public class HDFCBank extends Bank {

	public int rateOfInterest() {
		System.out.println("rateOfInterest= 8.5%");
		return 0;
	}
}
