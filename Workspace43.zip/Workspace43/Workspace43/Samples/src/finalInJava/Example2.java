package finalInJava;

public class Example2 {
	
	final void test1(){
		
	}
}
