package finalInJava;

public class Example3 extends Example2{

//	final void test1() {
//
//	}

}
