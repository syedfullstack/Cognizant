package finalInJava;

public final class Example4 {

}
