package finalInJava;

public class Example7 {

	final int speedlimit;

	Example7() {
		speedlimit = 70;
		System.out.println(speedlimit);
	}

	public static void main(String args[]) {
		new Example7();
	}
}
