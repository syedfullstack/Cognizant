package interfaceInjava;

public interface Example6 {

	void method6();
}
