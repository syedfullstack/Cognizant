package interfaceInjava;

public class TestExample7 implements Example7{

	@Override
	public void method5() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void method6() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void tset56() {
		// TODO Auto-generated method stub
		
	}


}
