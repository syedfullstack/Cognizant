package interfaceInjava;

public interface B1 {

	void test1();
	void test2();
}
