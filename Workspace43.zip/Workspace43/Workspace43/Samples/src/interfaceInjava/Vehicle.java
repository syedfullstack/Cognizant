package interfaceInjava;

public interface Vehicle {
	
	void changeGear(int a);

	void speedUp(int a);

	void applyBrakes(int a);
}
