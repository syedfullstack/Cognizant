package encapsulationInJava;

public class GroundCoffee {

}