package abstractInJava;

public abstract class A {
	
	int i = 90;
	int j;
	
	public static final int k = 900;

	A() {

	}

	A(int a) {

	}
	
	abstract void test1();
	
	void test(){
		
	}
}
