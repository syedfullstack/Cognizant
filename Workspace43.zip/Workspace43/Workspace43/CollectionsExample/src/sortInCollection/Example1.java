package collectionFramework.sortInCollection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class Example1 {

	public static void main(String[] args) {
		ArrayList<String> coll = new ArrayList<String>();
		coll.add("Test1");
		coll.add("Test5");
		coll.add("Test3");
		coll.add("Test4");

		Collections.sort(coll);
		Iterator itr = coll.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
