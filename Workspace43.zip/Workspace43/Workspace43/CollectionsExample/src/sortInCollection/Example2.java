package sortInCollection;

import java.util.ArrayList;
import java.util.Collections;


public class Example2 {

	public static void main(String[] args) {
		ArrayList<Customer> array = new ArrayList<Customer>();
		array.add(new Customer("Test1", 95, 200, "area"));
		array.add(new Customer("Test4", 75, 201, "area1"));
		array.add(new Customer("Test3", 20, 202, "area2"));
		array.add(new Customer("Test6", 50, 203, "area3"));

		Collections.sort(array);
		for (Customer c : array) {
			System.out.println(c.name + " " + c.age + " " + c.money+" "+c.area);
		}
	}
}
