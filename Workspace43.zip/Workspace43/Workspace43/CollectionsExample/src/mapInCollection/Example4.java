package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.Map.Entry;

public class Example4 {

	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(10, "Test1");
		map.put(11, "Test2");
		map.put(12, "Test3");
		for (Entry<Integer, String> m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}
