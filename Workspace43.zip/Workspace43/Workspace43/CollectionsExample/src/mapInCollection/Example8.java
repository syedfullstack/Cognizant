package collectionFramework.mapInCollection;

import java.util.Map.Entry;
import java.util.TreeMap;

public class Example8 {

	public static void main(String args[]) {
		TreeMap<Integer, String> hm = new TreeMap<Integer, String>();
		hm.put(10, "Test1");
		hm.put(12, "Test2");
		hm.put(11, "Test3");
		hm.put(13, "Test4");
		
		System.out.println(hm);
		for (Entry<Integer, String> m : hm.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}
