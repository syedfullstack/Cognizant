package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.Map;

public class Example3 {
	public static void main(String args[]) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(100, "Test1");
		map.put(101, "Test2");
		map.put(102, "Test3");
		map.put(10, "Test3");
		map.put(12, "Test3");
		map.put(102, "Test3");
		System.out.println(map);
	}
}
