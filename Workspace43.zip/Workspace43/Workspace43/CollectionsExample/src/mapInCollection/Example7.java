package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.LinkedHashMap;

public class Example7 {

	public static void main(String[] args) {
		LinkedHashMap<Integer, String> map = new LinkedHashMap<Integer, String>();
		map.put(1200, "Test3");
		map.put(10, "Test1");
		map.put(11, "Test2");
		map.put(12, "Test3");
		map.put(120000, "Test3");
		System.out.println( map);
	}
}
