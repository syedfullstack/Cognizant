package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.Map;

public class Example6 {

	public static void main(String[] args) {

		Map<Integer, Customer> map = new HashMap<Integer, Customer>();
		map.put(1, new Customer("Test1", 30, 40000, "area1"));
		map.put(2, new Customer("Test2", 31, 20000, "area2"));
		map.put(3, new Customer("Test3", 32, 30000, "area3"));
		map.put(4, new Customer("Test4", 33, 50000, "area4"));
		map.put(4, new Customer("Test4", 33, 50000, "area4"));

		// Traversing map
		for (Map.Entry<Integer, Customer> entry : map.entrySet()) {
			Customer c = entry.getValue();
			System.out.println(entry.getKey()+" " + c.name + " " + c.age + " " + c.money + " " + c.area);
		}
	}
}
