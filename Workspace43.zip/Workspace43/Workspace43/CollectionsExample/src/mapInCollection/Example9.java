package collectionFramework.mapInCollection;

import java.util.Map;
import java.util.TreeMap;

public class Example9 {

	public static void main(String[] args) {
		TreeMap<Integer, Customer> tm = new TreeMap<Integer, Customer>();
		tm.put(201, new Customer("Test1", 20, 200, "area1"));
		tm.put(203, new Customer("Test20", 21, 201, "area2"));
		tm.put(205, new Customer("Test3", 22, 202, "area3"));
		tm.put(208, new Customer("Test4", 23, 203, "area4"));
		tm.put(202, new Customer("Test5", 24, 204, "area5"));

		// Traversing map
		for (Map.Entry<Integer, Customer> entry : tm.entrySet()) {
			Customer c = entry.getValue();
			System.out.println(entry.getKey() + " " + c.name + " " + c.age + " " + c.money + " " + c.area);
		}
	}
}
