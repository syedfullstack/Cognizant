package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

public class Example2 {

	// non-generic example
	public static void main(String[] args) {
		Map map = new HashMap();
		// Adding elements to map
		map.put(1, "Test1");
		map.put(5, "Test2");
		map.put(2, "Test3");
		map.put(6, "Test4");
		map.put("tset5", "Test4");
		
		// Traversing Map
		Set set = map.entrySet();// Converting to Set so that we can traverse
		Iterator itr = set.iterator();
		while (itr.hasNext()) {
			// Converting to Map.Entry so that we can get key and value
			// separately
			Map.Entry entry = (Map.Entry) itr.next();
			System.out.println(entry.getKey() + " " + entry.getValue());
		}
	}
}
