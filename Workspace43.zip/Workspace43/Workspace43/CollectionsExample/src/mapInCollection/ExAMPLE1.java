package collectionFramework.mapInCollection;

import java.util.HashMap;
import java.util.Map;
import java.util.Map.Entry;

public class ExAMPLE1 {
	public static void main(String args[]) {
		Map<Integer, String> map = new HashMap<Integer, String>();
		map.put(100, "Test1");
		map.put(101, "Test2");
		map.put(102, "Test3");
		map.put(null, "Test3");
		map.put(103, null);
		map.put(104, null);
		map.put(105, null);
		
		System.out.println(map);
		for (Entry<Integer, String> m : map.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}
