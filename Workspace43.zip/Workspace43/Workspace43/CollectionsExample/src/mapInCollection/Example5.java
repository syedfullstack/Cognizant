package collectionFramework.mapInCollection;

import java.util.HashMap;

public class Example5 {

	public static void main(String[] args) {
		HashMap<Integer, String> map = new HashMap<Integer, String>();
		map.put(1200, "Test3");
		map.put(10, "Test1");
		map.put(11, "Test2");
		map.put(12, "Test3");
		map.put(120000, "Test3");
		System.out.println("before delete: "+ map);
		map.remove(10);
		System.out.println("after delete: "+ map);
		
		
		
	}
}
