package collectionFramework.sortInCollection.ComparatorInterface;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;


public class Example3 {
	
	public static void main(String[] args) {
		ArrayList<Customer> array = new ArrayList<Customer>();
		array.add(new Customer("Test1", 20, 200, "area"));
		array.add(new Customer("Test4", 22, 201, "area1"));
		array.add(new Customer("Test3", 23, 202, "area2"));
		array.add(new Customer("Test6", 24, 203, "area3"));

		System.out.println("Sorting by Name...");

		Collections.sort(array, new NameComparator());
		Iterator itr = array.iterator();
		while (itr.hasNext()) {
			Customer cs = (Customer) itr.next();
			System.out.println(cs.name + " " + cs.age + " " + cs.money + " " + cs.area);
		}

		System.out.println("sorting by age...");

		Collections.sort(array, new AgeComparator());
		Iterator itr2 = array.iterator();
		while (itr2.hasNext()) {
			Customer cs1 = (Customer) itr2.next();
			System.out.println(cs1.name + " " + cs1.age + " " + cs1.money + " " + cs1.area);
		}
		
		System.out.println("sorting by Money...");

		Collections.sort(array, new MoneyComparator());
		Iterator itr3 = array.iterator();
		while (itr3.hasNext()) {
			Customer cs1 = (Customer) itr3.next();
			System.out.println(cs1.name + " " + cs1.age + " " + cs1.money + " " + cs1.area);
		}

	}
}
