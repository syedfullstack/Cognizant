package collectionFramework.arrayList;

import java.util.ArrayList;

public class Example8 {
	
	public static void main(String[] args) {
		ArrayList<Integer> array = new ArrayList<Integer>();
		
		array.add(2);
		array.add(Integer.valueOf(2));
		
		array.add(2,90);
		
		System.out.println(array);
		
	}

}
