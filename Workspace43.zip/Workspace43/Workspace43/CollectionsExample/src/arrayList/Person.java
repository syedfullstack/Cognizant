package collectionFramework.arrayList;

public class Person {

	int rollno;
	String name;
	int age;

	Person(int rollno, String name, int age) {
		this.rollno = rollno;
		this.name = name;
		this.age = age;
	}
}
