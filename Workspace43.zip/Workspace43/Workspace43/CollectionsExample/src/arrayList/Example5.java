package collectionFramework.arrayList;
import java.util.ArrayList;
import java.util.List;

public class Example5 {

	public static void main(String[] args) {
		
		//Creating list of Customer  
	    List<Customer> list=new ArrayList<Customer>(); 
	    Customer obj1 = new Customer("Test1", 25, 800, "area1");
	    Customer obj2 = new Customer("Test1", 25, 800, "area1");
	    Customer obj3 = new Customer("Test1", 25, 800, "area1");
	    Customer obj4 = new Customer("Test1", 25, 800, "area1");
	    
	    list.add(obj1);
	    list.add(obj2);
	    list.add(obj3);
	    list.add(obj4);
	    
	    //Traversing list  
	    for(Customer c:list){  
	        System.out.println(c.name+" "+c.age+" "+c.money+" "+c.area);  
	    }  
	}
}
