package collectionFramework.arrayList;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

public class Example6 {

	public static void main(String[] args) {
		// Creating Array list Object
		List<String> list = new ArrayList<String>();
		// Adding object in Array list
		list.add("Bhanu");
		list.add("Pratap");
		list.add("Singh");
		list.add("Test1");
		// Traversing list through Iterator
		Iterator<String> itr = list.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
