package collectionFramework.hashSet;

import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashSet;

public class Example6 {
	public static void main(String[] args) {

		// Creating HashSet object and adding elements
		LinkedHashSet<String> set = new LinkedHashSet<String>();
		set.add("test1");
		set.add("test5");
		set.add("test6");
		// Traversing elements
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		System.out.println("-------");
		// Creating HashSet object and adding elements
		HashSet<String> set1 = new HashSet<String>();
		set1.add("test1");
		set1.add("test5");
		set1.add("test6");
		// Traversing elements
		Iterator<String> itr1 = set1.iterator();
		while (itr1.hasNext()) {
			System.out.println(itr1.next());
		}
	}
}
