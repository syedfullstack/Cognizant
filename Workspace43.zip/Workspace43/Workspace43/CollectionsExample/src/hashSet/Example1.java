package collectionFramework.hashSet;

import java.util.HashSet;
import java.util.Iterator;

public class Example1 {

	public static void main(String[] args) {
		// Creating HashSet object and adding elements
		HashSet<String> set = new HashSet<String>();
		set.add("Test1");
		set.add("Test2");
		set.add("Test3");
		set.add("Test4");
		set.add("Test4");
		
		System.out.println(set);
		// Traversing elements
		Iterator<String> itr = set.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
		
		// Creating HashSet object and adding elements
		HashSet<String> set1 = new HashSet<String>();
		set1.add("Test1");
		set1.add("Test2");
		set1.add("Test3");
		set1.add("Test4");
		
		set.addAll(set1);
	}
}
