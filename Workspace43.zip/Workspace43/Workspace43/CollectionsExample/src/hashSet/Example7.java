package collectionFramework.hashSet;

import java.util.Iterator;
import java.util.TreeSet;

public class Example7 {
	
	public static void main(String[] args) {

		// Creating and adding elements
		TreeSet<Integer> al = new TreeSet<Integer>();
		al.add(90);
		al.add(70);
		al.add(30);
		al.add(10);
		// Traversing elements
		Iterator<Integer> itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}
