package collectionFramework.hashSet;

public class Customer {
	
	String name;
	int age;
	int money;
	String area;
	
	public Customer(String name, int age, int money, String area) {
		super();
		this.name = name;
		this.age = age;
		this.money = money;
		this.area = area;
	}
}
