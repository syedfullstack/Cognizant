package collectionFramework.hashSet;

import java.util.HashSet;
import java.util.Set;

public class Example5 {
	
	public static void main(String[] args) {
		
		//Creating list of Customer  
	    Set<Customer> set=new HashSet<Customer>(); 
	    Customer obj1 = new Customer("Test1", 25, 800, "area1");
	    Customer obj2 = new Customer("Test2", 25, 800, "area1");
	    Customer obj3 = new Customer("Test3", 25, 800, "area1");
	    Customer obj4 = new Customer("Test4", 25, 800, "area1");
	    
	    set.add(obj1);
	    set.add(obj2);
	    set.add(obj3);
	    set.add(obj4);
	    
	    //Traversing list  
	    for(Customer c:set){  
	        System.out.println(c.name+" "+c.age+" "+c.money+" "+c.area);  
	    }  
	}
}
