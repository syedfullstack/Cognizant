package collectionFramework.hashTableClass;

import java.util.Hashtable;
import java.util.Map;

public class Example1 {

	public static void main(String[] args) {
		Hashtable<Integer, String> ht = new Hashtable<Integer, String>();

		ht.put(10, "Test1");
		ht.put(12, "Test2");
		ht.put(11, "Test3");
		ht.put(13, "Test4");
		//ht.put(null, "Test4");

		for (Map.Entry m : ht.entrySet()) {
			System.out.println(m.getKey() + " " + m.getValue());
		}
	}
}
