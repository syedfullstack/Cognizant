package collectionFramework.linkedList;

import java.util.LinkedList;

public class A {
	
	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<String>();
		list.add("Test1");
		list.add("Test2");
		list.add("Test3");
		
		System.out.println(list);
		System.out.println(list.getFirst());
		System.out.println(list.get(2));
		
		
		LinkedList<String> list1 = new LinkedList<String>();
		list1.add("Test4");
		list1.add("Test5");
		list1.add("Test3");
		
		list.addAll(list1);
		
		System.out.println(list);
		
		list.retainAll(list1);
		System.out.println(list);
		System.out.println(list.getFirst());
	}

}
