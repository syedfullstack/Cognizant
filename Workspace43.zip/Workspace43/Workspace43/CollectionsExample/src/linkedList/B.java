package collectionFramework.linkedList;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class B {

	public static void main(String[] args) {
		LinkedList<String> list = new LinkedList<String>();
		list.add("Test1");
		list.add("Test2");
		list.add("Test3");
		System.out.println(list.getLast());
		
		System.out.println(list.indexOf("Test2"));
		
		System.out.println(list.indexOf("Test5"));
	}
}
