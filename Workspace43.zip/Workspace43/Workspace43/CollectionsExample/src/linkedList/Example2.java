package collectionFramework.linkedList;

import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Example2 {

	public static void main(String args[]) {

		List<String> al = new ArrayList<String>();// creating arraylist
		al.add("Test1");// adding object in arraylist
		al.add("Test2");
		al.add("Test3");
		al.add("Test4");

		List<String> al2 = new LinkedList<String>();// creating linkedlist
		al2.add("Test1");// adding object in linkedlist
		al2.add("Test2");
		al2.add("Test3");
		al2.add("Test4");

		System.out.println("arraylist: " + al);
		System.out.println("linkedlist: " + al2);
	}
}
