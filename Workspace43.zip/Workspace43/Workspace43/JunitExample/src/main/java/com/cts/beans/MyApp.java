package com.cts.beans;

public class MyApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Calculator calc= new Calculator();
		Integer result=calc.add(10, 40);
		System.out.println(result);

	}

}
