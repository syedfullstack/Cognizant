

//Comparable interface from java.lang

public class Customer implements Comparable<Customer> {

	String name;
	int age;
	int money;
	String area;

	public Customer(String name, int age, int money, String area) {
		super();
		this.name = name;
		this.age = age;
		this.money = money;
		this.area = area;
	}
	/*public int compareTo(Customer c) {
		if (age == c.age) {
			return 0;
		} else if (age < c.age) {
			return 1;
		} else {
			return -1;
		}
	}*/
	
	public int compareTo(Customer person) {  
	    return person.name.compareTo(name);  
	      
	  }   
	

	
	}
	