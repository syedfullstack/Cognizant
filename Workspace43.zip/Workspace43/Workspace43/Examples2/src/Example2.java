
import java.util.ArrayList;
import java.util.Collections;


public class Example2 {

	public static void main(String[] args) {
		ArrayList<Customer> array = new ArrayList<Customer>();
		array.add(new Customer("Zen", 20, 200, "area"));
		array.add(new Customer("Rajesh", 32, 201, "area1"));
		array.add(new Customer("Praksh", 24, 202, "area2"));
		array.add(new Customer("Monica", 86, 203, "area3"));
		array.add(new Customer("Sana", 17, 200, "area"));
		array.add(new Customer("Alka", 22, 201, "area1"));
		array.add(new Customer("Christy", 24, 202, "area2"));
		array.add(new Customer("Test6", 8, 203, "area3"));
		array.add(new Customer("Magna", 9, 200, "area"));
		array.add(new Customer("Ahsok", 22, 201, "area1"));
		array.add(new Customer("Zubair", 24, 202, "area2"));
		array.add(new Customer("Thilak", 33, 203, "area3"));
		
		Collections.sort(array);
		
		
		for (Customer c : array) {
			System.out.println(c.name + " " + c.age + " " + c.money+" "+c.area);
		}
	}
}
