
import java.util.*;

class TestSort1 {
	public static void main(String args[]) {

		ArrayList<String> al = new ArrayList<String>();
		//ArrayList al = new ArrayList();
		al.add("Viru");
		al.add("Saurav");
		al.add("Mukesh");
		al.add("Zen");
		al.add("Yash");
		al.add("Ashok");
		al.add(230);
		

		Collections.sort(al);
		//Collections.sort(al,Collections.reverseOrder());  
		
		Iterator itr = al.iterator();
		while (itr.hasNext()) {
			System.out.println(itr.next());
		}
	}
}