import java.sql.CallableStatement;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;

import com.mysql.jdbc.Connection;
import com.mysql.jdbc.Statement;

public class AccountDAO {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//Load the Driver
		//Checked Exception
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish the Connection
			Connection con = (Connection) DriverManager.getConnection("jdbc:mysql://localhost/mydb44", "root", "test");
			System.out.println(con);
			System.out.println("Successfully Connected");
			
			
             //Insert Statement
			
			Statement statement=(Statement)con.createStatement();
			//int result=statement.executeUpdate("insert into account values(4,'Manoj','Kumar',80000)");
			//System.out.println(result+"rows got inserted");
			
			
			//int result=statement.executeUpdate("update account set bal=85000 where accno=1");
			//System.out.println(result+"rows got updated");
			
			
			//int result=statement.executeUpdate("delete from account where accno=2");
			//System.out.println(result+"rows got deleted");
			
			//Query Statement.
			/*
			ResultSet rs =statement.executeQuery("select * from account");
			//rs.absolute(2);  
			while(rs.next()) 
			{		
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
			
			}
			System.out.println("Query Executed Successfully");*/
			
			/*
			PreparedStatement stmt=con.prepareStatement("insert into account values(?,?,?,?)");

			stmt.setInt(1, 2);
			stmt.setString(2, "Lokesh");
			stmt.setString(3, "Chander");
			stmt.setInt(4, 9000); 
			
            int result = stmt.executeUpdate();
			
			System.out.println("Sucessfully Prepared Statement Updated");*/
			
			
			/*CallableStatement stmt=con.prepareCall("{call updateAccount(?,?,?,?)}");  
			stmt.setInt(1,12);  
			stmt.setString(2,"Barrak");
			stmt.setString(3,"Obama");
			stmt.setInt(4,50000);
			
			stmt.execute();  
			
			System.out.println("Sucessfully Callable Statement Inserted");*/
			/*
			CallableStatement stmt=con.prepareCall("{?= call sum4(?,?)}");  
			stmt.setInt(2,10);  
			stmt.setInt(3,43);  
			stmt.registerOutParameter(1,Types.INTEGER);  
			stmt.execute();  
			  
			System.out.println(stmt.getInt(1));  
			*/
			
			
			// Resulset Meta Data- Information about Table and Colunmn

			PreparedStatement ps=con.prepareStatement("select * from account");  

			ResultSet rs=ps.executeQuery();  
			ResultSetMetaData rsmd=rs.getMetaData();  
			  
			System.out.println("Total columns: "+rsmd.getColumnCount());  

			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(1));  
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(1));

			System.out.println("=====================================");

			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(2));  
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(2));	

			System.out.println("=====================================");

			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(3));  
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(3));	
			System.out.println("=====================================");
			System.out.println("Column Name of 1st column: "+rsmd.getColumnName(4));  
			System.out.println("Column Type Name of 1st column: "+rsmd.getColumnTypeName(4));				
						
			
			


			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		

	}

}
