package in.ashokit.beans;

public class Calculator {

	public Integer add(Integer a, Integer b) {
		return a + b;
	}

	public Integer multiply(Integer a, Integer b) {
		return a * b;
	}
}
