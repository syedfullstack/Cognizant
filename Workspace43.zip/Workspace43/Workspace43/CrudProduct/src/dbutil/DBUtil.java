package dbutil;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.sql.Types;

//import com.mysql.jdbc.Connection;
//import com.mysql.jdbc.Statement;


public class DBUtil {
	
	public static Connection getConnection()
	{
		java.sql.Connection conn = null;
		try 
		{
			/*
			
			
			//Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish the Connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb2", "root", "test");
			
			
			
			*/
			
			System.out.println("step1"); 
			Class.forName("com.mysql.jdbc.Driver");
			System.out.println("step2"); 
		    conn = DriverManager.getConnection("jdbc:mysql://localhost/products", "root", "test");
		    System.out.println(conn); 
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		return conn;
	}
	
	
	public static void closeConnection(Connection conn)
	{
		try {
			conn.close();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}
