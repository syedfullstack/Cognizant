package in.easymock.service.test;

import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;

import org.easymock.EasyMock;
import org.junit.Test;

import in.easymock.dao.ContactDao;
import in.easymock.service.ContactService;
import in.easymock.service.ContactServiceImpl;

public class ContactServiceTest {

	@Test
	public void testGetNameById_01() {

		ContactDao daoProxy = EasyMock.createMock(ContactDao.class);

		// setting behaviour for proxy
		EasyMock.expect(daoProxy.getNameById(101)).andReturn("Ashok");
		EasyMock.expect(daoProxy.getNameById(102)).andReturn("Syed");
		EasyMock.expect(daoProxy.getNameById(103)).andReturn("Mukesh");
		EasyMock.expect(daoProxy.getNameById(104)).andReturn("Kalyani");
		EasyMock.replay(daoProxy);

		ContactService service = new ContactServiceImpl();
		service.setContactDao(daoProxy);

		// ContactService service=new ContactServiceImpl();
		String name = service.getNameById(103);
		System.out.println(name);
		assertNotNull(name);

	}

}
