package in.easymock.service;

import in.easymock.dao.ContactDao;

public interface ContactService {
	
	public String getNameById(Integer id);
	public void setContactDao(ContactDao contactDao);

}
