package in.easymock.dao;

public interface ContactDao {
	
	public String getNameById(Integer id);

}
