package in.easymock.service;

import in.easymock.dao.ContactDao;

public class ContactServiceImpl implements ContactService {

	private ContactDao contactDao;

	public void setContactDao(ContactDao contactDao) {

		this.contactDao = contactDao;

	}

	public String getNameById(Integer id)

	{
		String name = contactDao.getNameById(id);

		// logic

		String formattedName = name.toUpperCase();
		return formattedName;

	}

}
