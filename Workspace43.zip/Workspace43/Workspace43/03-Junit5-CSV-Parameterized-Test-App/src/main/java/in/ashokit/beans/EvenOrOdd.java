package in.ashokit.beans;

public class EvenOrOdd {

	public String evenOrOddNum(Integer num) {
		if (num % 2 == 0) {
			return "even";
		}
		return "odd";
	}
}
