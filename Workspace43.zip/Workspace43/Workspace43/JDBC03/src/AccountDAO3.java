
import java.sql.*; 
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.PreparedStatement;


public class AccountDAO3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		try {
			Class.forName("com.mysql.jdbc.Driver");
			
			//Load the Driver
			Class.forName("com.mysql.jdbc.Driver");
			
			//Establish the Connection
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/mydb2", "root", "test");
            //Testing
			
			//System.out.println(con);
			//System.out.println("Successfully Connected");
			
            //Insert Statement
			
			Statement statement=con.createStatement();
			//int result=statement.executeUpdate("insert into account values(99,'Salman','Khan',90000)");
			//System.out.println(result+"rows got inserted");
			
			 //Update Statement
			//int result=statement.executeUpdate("update account set bal=70000 where accno=99");
			//System.out.println(result+"rows got updated");
			
			//Delete Operation
			//int result=statement.executeUpdate("delete from account where accno=99");
			//System.out.println(result+"rows got deleted");
			
			/*ResultSet rs =statement.executeQuery("select * from account");
			//rs.absolute(3); 
			while(rs.next()) {
			System.out.println(rs.getInt(1)+" "+rs.getString(2)+" "+rs.getString(3)+" "+rs.getInt(4));
			//System.out.println("Query Executed Successfully");
			}*/
			
			
			/*PreparedStatement stmt=con.prepareStatement("insert into account values(?,?,?,?)");
			stmt.setInt(1, 99);
			stmt.setString(2, "Amir");
			stmt.setString(3, "Khan");
			stmt.setInt(4, 80000);
			
			int result = stmt.executeUpdate();
			
			System.out.println("Sucessfully Updated");*/
			
			CallableStatement stmt=con.prepareCall("{call updateAccount(?,?,?,?)}");  
			stmt.setInt(1,88);  
			stmt.setString(2,"Joe");
			stmt.setString(3,"Biden");
			stmt.setInt(4,66000);
			
			stmt.execute();  
			
			System.out.println("Sucessfully Inserted");
			
			





			
			
		} catch (ClassNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}


/**
 * 
 * 
 * create database mydb3;
   use mydb3; 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 * 
 */
