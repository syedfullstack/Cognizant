package com.cts.bean.test;

import static org.junit.Assert.assertEquals;

import org.junit.AfterClass;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cts.bean.Calculator;

public class CalculatorTest {

	private static Calculator calc = null;

	@BeforeClass
	public static void init() {
		calc = new Calculator();
	}

	@AfterClass
	public static void detroy() {

		calc = null;
	}

	@Test
	public void testAdd() {

		// Calculator calc = new Calculator();

		Integer actualResult = calc.add(10, 20);
		Integer expectedResult = 30;

		assertEquals(expectedResult, actualResult);

	}

	@Test
	public void testMultiply() {

		// Calculator calc = new Calculator();

		Integer actualResult = calc.multiply(2, 3);
		Integer expectedResult = 6;

		assertEquals(expectedResult, actualResult);

	}

}
