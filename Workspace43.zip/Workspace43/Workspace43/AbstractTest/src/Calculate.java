abstract class Plan
{
	
	public double rate;
	
	public abstract void getRate();
	
	
	public void CalculatBill(int units)
	{
		
		System.out.println("Bill Amount for  "+units+"   Units:");
		
		System.out.println(rate*units);
	}
	
	
	
}


class CommercialPlan extends Plan
{

	@Override
	public void getRate() {
		
		rate=9.00;
		
		System.out.println("Rate per Unit for Commercial Usage"+rate);
	}
	
	
	
}



class DomesticPlan extends Plan
{

	@Override
	public void getRate() {
		
		rate=5.00;
		
		System.out.println("Rate per Unit for Domestic Usage"+rate);
	}
	
	
	
}



public class Calculate {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Plan p;
		
		System.out.println("Commercial Connection");
		
		p=new CommercialPlan();
		p.getRate();
		p.CalculatBill(500);
		
		
		
System.out.println("Domestic Connection");
		
		p=new DomesticPlan();
		p.getRate();
		p.CalculatBill(200);

	}

}
