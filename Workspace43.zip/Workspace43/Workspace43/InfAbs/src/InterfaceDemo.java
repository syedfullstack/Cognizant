interface MyInter
{
	
	void connect();
	void disconnect();
	

}

class OracleDB implements MyInter
{

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		System.out.println("Connect Oracle");
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		System.out.println("Disconnect Oracle");
		
	}
	
	
	
}



class MySQLDB implements MyInter
{

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		System.out.println("Connect MYSQLDB");
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		System.out.println("DisConnect MYSQLDB");
		
	}
	
	
	
}

class IBMDB2DB implements MyInter
{

	@Override
	public void connect() {
		// TODO Auto-generated method stub
		System.out.println("Connect IBM");
		
	}

	@Override
	public void disconnect() {
		// TODO Auto-generated method stub
		System.out.println("DisConnect IBM");
		
	}
	
	
	
}


public class InterfaceDemo {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class c=Class.forName(args[0]);
		MyInter mi=(MyInter)c.newInstance();
		
		mi.connect();
		mi.disconnect();

	}

}
