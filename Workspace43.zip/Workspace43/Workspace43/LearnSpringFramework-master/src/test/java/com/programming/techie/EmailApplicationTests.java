package com.programming.techie;

public class EmailApplicationTests {
}
