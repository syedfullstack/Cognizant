
public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		
		//String str1="Welcome1";
		//String str2="Welcome";
		//String str5="Welcome1";
		
		//String str1=new String("Welcome");
		//String str2=new String("Welcome");
				
		
		/*System.out.println(str1.hashCode());
		System.out.println(str2.hashCode());
		System.out.println(str5.hashCode());*/
		
		
		
		StringBuffer str3=new StringBuffer("Welcome");
		StringBuffer str4=new StringBuffer("Welcome");
		
		System.out.println(str3.hashCode());
		System.out.println(str4.hashCode());
		
		
		 

	}

}
