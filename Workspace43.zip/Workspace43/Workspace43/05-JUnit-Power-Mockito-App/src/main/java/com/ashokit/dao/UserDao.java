package com.ashokit.dao;

public interface UserDao {
	
	public String findNameById(Integer id);
	
	public String findEmailById(Integer id);

}
