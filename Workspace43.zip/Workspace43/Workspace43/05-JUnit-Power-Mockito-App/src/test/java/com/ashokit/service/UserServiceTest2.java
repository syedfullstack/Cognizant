package com.ashokit.service;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertNotNull;
import static org.mockito.Matchers.anyString;

import org.junit.Test;
import org.powermock.api.mockito.PowerMockito;

import com.ashokit.dao.UserDao;
import com.ashokit.dao.UserDaoImpl;

public class UserServiceTest2 {

	@Test
	public void testGetNameByUserId() {
		//UserDao mockDao = PowerMockito.mock(UserDaoImpl.class);
		 UserDao mockDao = PowerMockito.mock(UserDao.class);
		PowerMockito.when(mockDao.findNameById(101)).thenReturn("Nick");
		PowerMockito.when(mockDao.findNameById(102)).thenReturn("Smith");
		PowerMockito.when(mockDao.findNameById(103)).thenCallRealMethod();


		UserService service = new UserService(mockDao);
		String name = service.getNameByUserId(101);
		//assertEquals("John", name);
		
		 assertEquals("Nick", name);
		
	}

	
}