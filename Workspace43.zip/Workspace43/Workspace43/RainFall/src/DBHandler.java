import java.sql.Connection;
import java.io.*;
import java.sql.*;
import java.util.*;
public class DBHandler {

	//Write the required business logic as expected in the question description
	public Connection establishConnection() {

		//fill the code
		Connection conn = null;
		try{
		    FileInputStream fis = new FileInputStream("src/db.properties");
		    Properties p = new Properties();
		    p.load(fis);
		    
		    Class.forName(p.getProperty("db.classname"));
		    
		    conn = DriverManager.getConnection(p.getProperty("db.url"),p.getProperty("db.username"),p.getProperty("db.password"));
		    
		    
		}
		catch(Exception e){
		    e.printStackTrace();
		}
		
		return conn;

	}
}
