
public class InvalidCityPincodeException extends Exception {
    public InvalidCityPincodeException(){
        
    }
    
    public InvalidCityPincodeException(String s){
        super(s);
    }
}
